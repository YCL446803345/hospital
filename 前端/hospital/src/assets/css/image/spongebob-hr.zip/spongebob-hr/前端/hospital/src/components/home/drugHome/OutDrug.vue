<template>
    <div>
        <h1>这是退药列表</h1>
    </div>
</template>

<script>
export default {
   data() {
      return {

      }
   },
   created(){

   },
   methods:{

   }
}
</script>

<style>

</style>
